 import React, { useState, useContext } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { mycontext } from "./GlobalContext";
import { toast } from "react-toastify";

const UpdateCourse = () => {
  const { logtoken } = useContext(mycontext);
  const loc = useLocation();
  const { id } = useParams(); // course id
  const nav = useNavigate();

  // Pre-fill form with course details from location state
  const [formData, setFormData] = useState({
    title: loc?.state?.title || "",
    description: loc?.state?.description || "",
    duration: loc?.state?.duration || "",
    price: loc?.state?.price || "",
    minimumSkill: loc?.state?.minimumSkill || "Beginner",
    scholarshipAvailable: loc?.state?.scholarshipAvailable || false,
    image: loc?.state?.image || "",
    bootcamp: loc?.state?.bootcamp || "", // keep bootcamp id
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === "radio" ? value === "true" : type === "checkbox" ? checked : value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      let res = await fetch(`http://localhost:5000/api/v1/courses/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${logtoken}`,
        },
        body: JSON.stringify(formData),
      });

      let data = await res.json();
      if (data.success) {
        toast.success("Course updated successfully ✅");
        // navigate back to BootcampDetails with updated data
        nav("/dashboard/bootcampdetails", { state: { ...loc.state.bootcamp, updated: true } });
      } else {
        toast.error(data.error || "Update failed");
      }
    } catch (err) {
      console.error(err);
      toast.error("Something went wrong");
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 rounded-xl shadow-md mt-6 text-white bg-black">
      <h2 className="text-2xl font-bold mb-4 text-center">Update Course</h2>
      <form className="space-y-4" onSubmit={handleSubmit}>
        <input
          type="text"
          name="title"
          placeholder="Course Title"
          value={formData.title}
          onChange={handleChange}
          className="w-full p-2 border rounded bg-gray-800"
        />
        <textarea
          name="description"
          placeholder="Description"
          value={formData.description}
          onChange={handleChange}
          className="w-full p-2 border rounded bg-gray-800"
        ></textarea>
        <input
          type="text"
          name="duration"
          placeholder="Duration"
          value={formData.duration}
          onChange={handleChange}
          className="w-full p-2 border rounded bg-gray-800"
        />
        <input
          type="number"
          name="price"
          placeholder="Price"
          value={formData.price}
          onChange={handleChange}
          className="w-full p-2 border rounded bg-gray-800"
        />
        <input
          type="url"
          name="image"
          placeholder="Image URL"
          value={formData.image}
          onChange={handleChange}
          className="w-full p-2 border rounded bg-gray-800"
        />
        <select
          name="minimumSkill"
          value={formData.minimumSkill}
          onChange={handleChange}
          className="w-full p-2 border rounded bg-gray-800"
        >
          <option value="Beginner">Beginner</option>
          <option value="Intermediate">Intermediate</option>
          <option value="Advanced">Advanced</option>
        </select>
        <div className="flex items-center space-x-4">
          <span>Scholarship available:</span>
          <label>
            <input
              type="radio"
              name="scholarshipAvailable"
              value="true"
              checked={formData.scholarshipAvailable === true}
              onChange={handleChange}
            />{" "}
            Yes
          </label>
          <label>
            <input
              type="radio"
              name="scholarshipAvailable"
              value="false"
              checked={formData.scholarshipAvailable === false}
              onChange={handleChange}
            />{" "}
            No
          </label>
        </div>
        <button
          type="submit"
          className="w-full bg-white text-black py-2 rounded font-semibold hover:bg-gradient-to-r from-black via-gray-700 to-white hover:text-white"
        >
          Update Course
        </button>
      </form>
    </div>
  );
};

export default UpdateCourse;
